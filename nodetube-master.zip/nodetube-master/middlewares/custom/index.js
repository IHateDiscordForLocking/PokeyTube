const iptracker = require('./iptracker');
const redirect = require('./redirect');
const zopim = require('./zopim');
const customBranding = require('./customBranding');

module.exports = {
  iptracker,
  redirect,
  zopim,
  customBranding
};