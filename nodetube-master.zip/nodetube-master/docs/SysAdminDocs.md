# logging
sudo vnstat -u -i eth0
sudo tcptrack -i eth0 port 80

sudo tcptrack -i eth0 port 443

sudo nethogs eth0

sudo easy_install pip

sudo pip install --upgrade b2

sudo npm install -g pm2

